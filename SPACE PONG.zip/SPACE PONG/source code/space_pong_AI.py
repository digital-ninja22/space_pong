# A game by Alex Iliescu (June 2021) - Pong with AI opponent

import pygame

pygame.init()

WIDTH, HEIGHT = 750, 500
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT)) 
BACKGROUND = pygame.image.load("galaxy750x500.jpg")   
#BACKGROUND2 = pygame.image.load("purplespace750x500.jpg")
#BACKGROUND3 = pygame.image.load("hubble750x500.jpg")

pygame.display.set_caption("SPACE PONG") 

WINNER_FONT = pygame.font.SysFont('comicsans', 100)

BLUE = (0, 0, 255)          
RED = (255, 0, 0)           
YELLOW = (255, 255, 0)     
WHITE = (255, 255, 255)     
#BLACK = (0, 0, 0)          

class Paddle(pygame.sprite.Sprite):     
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)    
        self.image = pygame.Surface([10, 75])
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()   
        self.paddle_speed = 7           
        self.points = 0

class Ball(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([10, 10])
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.speed = 5    
        self.dx = 1     # ball direction on x-axis    
        self.dy = 1     # ball direction on y-axis

paddle1 = Paddle()
paddle1.image.fill(BLUE)
paddle1.rect.x = 25      
paddle1.rect.y = 212     

paddle2 = Paddle()
paddle2.image.fill(RED)
paddle2.rect.x = 715
paddle2.rect.y = 212
paddle2.paddle_speed = 4

ball = Ball()
ball.rect.x = 375
ball.rect.y = 250

all_sprites = pygame.sprite.Group() 
all_sprites.add(paddle1, paddle2, ball)


def redraw():
    #WINDOW.fill(BLACK)
    WINDOW.blit(BACKGROUND, (0,0))

    font = pygame.font.SysFont("Consolas", 35)
    text = font.render("[SPACE PONG]", 1, YELLOW)
    textRect = text.get_rect()      
    textRect.center = (WIDTH//2, 25) 
    WINDOW.blit(text, textRect)     

    p1_score = font.render(str([paddle1.points]), 1, WHITE)
    p1Rect = p1_score.get_rect()    
    p1Rect.center = (50, 50)        
    WINDOW.blit(p1_score, p1Rect)   
    
    p2_score = font.render(str([paddle2.points]), 1, WHITE)
    p2Rect = p2_score.get_rect()
    p2Rect.center = (700, 50)       
    WINDOW.blit(p2_score, p2Rect)
    
    all_sprites.draw(WINDOW)    
    pygame.display.update()
    

def paddle_movement(key_pressed, paddle2Rect):
    if key_pressed[pygame.K_w]:
        paddle1.rect.y -= paddle1.paddle_speed
        
    if key_pressed[pygame.K_s]:
        paddle1.rect.y += paddle1.paddle_speed

    # Paddle2 is the opponent AI and it moves depending on the baall's position
    # speed of opponent determines difficulty       
    if paddle2.rect.y < ball.rect.y:
        paddle2.rect.y += paddle2.paddle_speed
        
    if paddle2.rect.y > ball.rect.y:
        paddle2.rect.y -= paddle2.paddle_speed
        

def collision_paddle_surface(paddle1Rect, paddle2Rect):
    if paddle1.rect.y < 0:
        paddle1.rect.y = 0
        
    if paddle1.rect.y > 425:
        paddle1.rect.y = 425

    if paddle2.rect.y < 0:
        paddle2.rect.y = 0
        
    if paddle2.rect.y > 425:
        paddle2.rect.y = 425


def ball_movement():
    ball.rect.x += ball.speed * ball.dx         
    ball.rect.y += ball.speed * ball.dy


def collision_ball_surface(ballY, ballX):
    if ball.rect.y > 490:   
        ball.dy = -1       

    if ball.rect.x > 740:   
        ball.rect.x, ball.rect.y = 375, 250     
        paddle1.points += 1

    if ball.rect.y < 10:    
        ball.dy = 1        

    if ball.rect.x < 0:    
        ball.rect.x, ball.rect.y = 375, 250
        paddle2.points += 1


def ball_speed_increase(P1_points, P2_points):
    if (paddle1.points >= 3 and paddle2.points >= 3) and (paddle1.points < 6 and paddle2.points < 6):
        ball.speed = 6
        paddle2.paddle_speed = 5

    if (paddle1.points >= 6 and paddle2.points >= 6):
        ball.speed = 7
        paddle2.paddle_speed = 6


def collision_ball_paddle(paddle1Rect, paddle2Rect):
    if paddle1.rect.colliderect(ball.rect):
        ball.dx = 1
        
    if paddle2.rect.colliderect(ball.rect):
        ball.dx = -1


def draw_winner(text):
    # The reson this is not included in redraw() is bc we only want to do this whenever someone wins and restart game right after
    draw_text = WINNER_FONT.render(text, 1, WHITE)
    WINDOW.blit(draw_text, (WIDTH//2 - draw_text.get_width()/2, HEIGHT//2 - draw_text.get_height()/2))  # This ensures text is centered
    pygame.display.update()
    pygame.time.delay(5000)     # Will show the winning text and pause the game for 5 seconds


def main():
    run = True

    while run:
        pygame.time.delay(15)   
   
        for event in pygame.event.get():    
            if event.type == pygame.QUIT:  
                run = False


        winner_text = ""
        if paddle1.points >= 10:
            winner_text = "Blue Wins!"

        if paddle2.points >= 10:
            winner_text = "Red Wins!"

        if winner_text != "":
            draw_winner(winner_text)
            paddle1.points = 0
            paddle2.points = 0
            ball.speed = 5
            paddle2.paddle_speed = 4
            

        key_pressed = pygame.key.get_pressed()
        
        paddle_movement(key_pressed, paddle2.rect)
        collision_paddle_surface(paddle1.rect.y, paddle2.rect.y)
    
        ball_movement()   

        collision_ball_surface(ball.rect.y, ball.rect.x)
        ball_speed_increase(paddle1.points, paddle2.points)
        collision_ball_paddle(paddle1.rect, paddle2.rect)
   
        redraw()  

    pygame.quit()

if __name__ == "__main__":
    main()
